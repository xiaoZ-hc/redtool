# shiro-check

- 比较通用的两种回显
- 扫描100key，20keys适配
- 自定义key回显
- 回显payload借鉴了XRAY
- 第一次使用请save配置，在repeater 中右键生成payload
- 请求头中设置命令参数TestCmd