# ProxySpider
爬取http://www.xicidaili.com/上代理IP，并验证代理可用性

#使用方法：
直接运行httpproxy.py

输出文件：

proxy.txt —— 所有爬到的代理

verified.txt —— 所有可用代理


参数修改：

line22：爬取的Page数量

line99：爬取的线程数
