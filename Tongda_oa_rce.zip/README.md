## 通达OA 越权登录 + 文件上传getshell

### Usage

```
pip install -r requirements.txt
python tongda.py
```
### 文件说明

- url.txt： 测试url，支持批量
- shell.txt：上传成功的webshell
- cookie.txt：登录成功的cookie
- webshell密码：a

### 已测试版本

< v11.5

### 根据中华人民共和国《网络安全法》相关政策规定，本文件只用以学习和安全测试，不被允许通过本文件中所提及技术手段进行非法行为，使用技术的风险由您自行承担

